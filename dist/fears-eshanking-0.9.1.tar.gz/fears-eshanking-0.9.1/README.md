# fears
Fast Evolution on ARbitrary Seascapes

FEArS is not yet an installable package- we are working on that. This software is version 0.9.

Steps to reproduce figures: 

1. clone this repository: git clone https://github.com/eshanking/fears/
2. add FEArS to your path: import sys -> sys.path.append(*fears directory path*)
3. Open and run examples/one_click_reproduction.py (this will take several hours to run)
4. Figures will be in figures folder. Data and p-values will be in results folder.
